﻿using System;

namespace Practica.DataAcces
{
    public class Class1
    {
    }
}
