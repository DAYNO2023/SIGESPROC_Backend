﻿using System;

namespace Practica.Entities
{
    public class Class1
    {
    }
}
