﻿using System;

namespace Practica.Common
{
    public class Class1
    {
    }
}
