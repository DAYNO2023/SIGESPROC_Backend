﻿using System;

namespace Practica.BussinesLogic
{
    public class Class1
    {
    }
}
